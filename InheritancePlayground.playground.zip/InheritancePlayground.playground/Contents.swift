//: Playground - noun: a place where people can play

import Foundation

class Shape {
    var x : Float
    var y : Float
    var width:Float
    var height:Float
    
    
    init(x:Float, y:Float, width:Float, height:Float) {
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        
    }
    
    convenience init(x:Float, y:Float) {
        self.init(x: x, y: y, width: 10, height: 20)
    }
    
    convenience init(x:Float, y:Float, width:Float) {
        self.init(x: x, y: y, width: width, height: 9)
        
    }

    
    func draw()  {
        print("draw")
    }
}

class Person {
    let name:String
    var age:Int?
    
    init?(name:String) {
        if name.isEmpty {
            return nil
        }
        
        self.name = name
    }
    
    init?(name:String, age:Int) {
        if name.isEmpty || age < 0 {
            return nil
        }
        
        self.name = name
    }
}


let yagom:Person? = Person(name: "yagom", age: 99)

if let person:Person = yagom {
        print(person.name)
}
else{
    print("Person wasn't initalized")
}


struct Student {
    var name:String?
    var number:Int?
}

class SchoolClass{
    var student:[Student] = {
        var arr:[Student] = [Student]()
        
        for num in 1...15{
            var student : Student = Student(name: nil, number: num)
            arr.append(student)
        }
        
        return arr
    }()
}

let myClass:SchoolClass = SchoolClass()

print(myClass.student.count)



func myFunc(){
    var i:Int = 10
    func yourFunc()
    {
//        var i:int = 20
        print(i)
    }
}


let names:[String] = ["wizplan", "eric", "yagom","jenny"]
let reversed:[String] = names.sorted(by: { (first, second) in
    return first > second
})

let reversed2:[String] = names.sorted {
    return $0 > $1
}


func makeIncrementer(forIncrement amount:Int) -> (() -> Int){
    var runningTotal = 0
    
    func incrementer() -> Int {
        runningTotal += amount
        return runningTotal
    }
    
    return incrementer
}

let incrementByTwo:(()-> Int) = makeIncrementer(forIncrement: 2)

let first:Int = incrementByTwo()
let second:Int = incrementByTwo()
let third:Int = incrementByTwo()



typealias VoidVoidClosure = () -> Void

let firstClosure:VoidVoidClosure = {
    print("Closure A")
}

let secondClosure:VoidVoidClosure = {
    print("Closure B")
}

func returnOneClosure(first : @escaping VoidVoidClosure, second : @escaping VoidVoidClosure,
                      shouldReturnFirstClosure:Bool) -> VoidVoidClosure {
    return shouldReturnFirstClosure ? first : second
}

let returnedClosure:VoidVoidClosure = returnOneClosure(first: firstClosure, second: secondClosure, shouldReturnFirstClosure: false)

returnedClosure()

var closures:[VoidVoidClosure] = []

func appendClosure(closure: @escaping VoidVoidClosure){
    closures.append(closure)
}


struct Point{
    var x : Int?
    var y : Int
    
    init(newX:Int, newY:Int) {
        self.x = newX
        self.y = newY
    }
    
    mutating func newPoint(x:Int, y:Int){
        self.x = x
        self.y = y
    }
}


//let p = Point(newX: 2, newY: 3)

struct Size {
    var width:Int?
    var height:Int
}

struct Frame{
    var point:Point
    var size:Size?
}

class Shape2{
    var frame:Frame?
    
    init(frame:Frame?) {
        self.frame = frame
    }
}

var frame = Frame(point: Point(newX: 10, newY:20), size: Size(width: 29, height: 29))
var shape = Shape2(frame: nil)

//shape.frame.size.width
//let width = shape.frame?.size?.width

if let oFrame = shape.frame {
    if let oSize = oFrame.size {
        if let oWidth = oSize.width {
            print(oWidth)
        }
    }
}
else{
    print("frame is nil")
}


let uWidth = shape.frame?.size?.width




