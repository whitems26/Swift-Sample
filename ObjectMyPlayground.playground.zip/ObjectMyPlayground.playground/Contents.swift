//: Playground - noun: a place where people can play

import Foundation

@objc protocol Movealbe{
    func walk()
    @objc optional func fly()
}

class Tiget:NSObject, Movealbe{
    func walk() {
        print("tiger walk")
    }
}

class Bird:NSObject, Movealbe{
    func walk() {
        print("bird walk")
    }
    
    func fly() {
        print("bird fly")
    }
    
    
}

let tiger:Tiget = Tiget()
let bird:Bird = Bird()
tiger.walk()
bird.fly()

var moveableInstance:Movealbe = tiger

moveableInstance.fly?()

moveableInstance = bird
moveableInstance.fly?()


