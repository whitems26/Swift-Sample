

class Person {
    var name :String
    private var age : Int
    var phoneNumber : String?
    
    var koreanAge : Int {
        get{
            return self.age + 1
        }
        
        set{
            self.age = newValue - 1
        }
        
//        set(newAge){
//            self.age = newAge - 1
//        }
    
//        return self.age - 1

    }
    var weight:Int = 0 {
        willSet{
            print("Current Value = \(self.weight) New Vaue = \(newValue)")
        }
        
        didSet{
            print("Old Value = \(oldValue) Current Value = \(self.weight)")
        }
    }
    
    
    
    init(name:String, age:Int, phoneNumber:String) {
        self.name = name
        self.age = age
        self.phoneNumber = phoneNumber
    }
    
    func walk() {
        print("Walk")
    }
    
}


let p1 = Person(name: "James", age: 29, phoneNumber: "0102320422")

print(p1)

p1.walk()

//p1.age = 20
//
p1.koreanAge = 33
//p1.age
//
//print(p1.age)

p1.weight = 3



class Shape {
    var x : Float
    var y : Float
    
    init(x:Float, y:Float) {
        self.x = x
        self.y = y
    }
    
    
    func draw()  {
        print("draw")
    }
}



class Rectangle : Shape {
    
    var width:Float
    var height:Float

    init(x:Float, y:Float, width:Float, height:Float) {
        self.width = width
        self.height = height
        super.init(x: x, y: y)
    }

    override func draw() {
        super.draw()
        print("new draw")
    }
}



let shape = Shape(x: 10, y: 10)

let rectangle = Rectangle(x: 20, y: 20, width : 23 , height : 23)

shape.draw()
rectangle.draw()
