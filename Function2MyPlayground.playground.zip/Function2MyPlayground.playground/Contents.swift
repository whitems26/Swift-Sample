//: Playground - noun: a place where people can play

class Shape{
    var x:Int
    var y:Int
    init(x:Int, y:Int) {
        self.x = x
        self.y = y
    }
    
    convenience init(x:Int){
        self.init(x: x, y: 9)
    }
}

class Rectangle:Shape{
    var width:Int
    var height:Int
    init(x:Int, y:Int, width:Int, height:Int) {
        self.width = width
        self.height = height
        super.init(x: x, y: y)
    }
    
    convenience init(x:Int, y:Int, width:Int){
 
        self.init(x: x, y: y, width: width, height:0)
    }
}


protocol PersonBDelegate {
    func send()
}

class PersonA : PersonBDelegate{
    
    init() {
        let personB = PersonB()
        personB.delegate = self
        
        personB.callMe()
        
    }
    func send()  {
        print("Received")
    }
}

class PersonB{
    var delegate:PersonBDelegate?
    
    func callMe()  {
        delegate?.send()
    }
}

let p1 = PersonA()


protocol SomeProtocol {
    var settableProperty:String { get set }
    var notNeedToBeSettableProperty:String { get }
}




protocol Sendable {
    var from:String {get}
    var to:String {get}
}

class Message:Sendable {
    var sender:String
    var from:String {
        return self.sender
    }
    
    var to:String
    
    init(sender:String, receiver:String) {
        self.sender = sender
        self.to = receiver
    }
    
}



class Mail:Sendable {
    var from: String
    var to: String
    init(sender:String, receiver:String) {
        self.from = sender
        self.to = receiver
    }
}



protocol Resettable {
    mutating func reset()
}

class Person:Resettable {
    
    var name:String?
    var age:Int?
    
    func reset()  {
        self.name = nil
        self.age = nil
    }
}

struct Point : Resettable{
    var x:Int = 0
    var y:Int = 0
    
    mutating func reset(){
        self.x = 0
        self.y = 0
    }
}

enum Direction:Resettable{
    case east, west, south, north, unknow
    
    mutating func reset() {
        self = Direction.unknow
    }
}


