//: Playground - noun: a place where people can play


protocol Named {
    var name:String {get}
    init(name:String)
}

struct Pet:Named{
    var name:String
    init(name:String) {
        self.name = name
    }
}

class Person:Named{
    var name:String
    required init(name: String) {
        self.name = name
    }
    
}

class School {
    var name:String
    init(name:String) {
        self.name = name
    }
    
}

class MiddleSchool:School, Named{
    
    required override init(name:String) {
        super.init(name: name)
    }
}

protocol Readable {
    func read()
}

protocol Writeable {
    func write()
}


protocol ReadSpeakable : Readable{
    func speak()
}

protocol ReadWriteSpeakable:Readable, Writeable{
    func speak()
}

class someClass:ReadSpeakable {
    func read() {
        print("Read")
    }
    
    func write(){
        print("write")
    }
    
    func speak() {
        print("speak")
    }
}


protocol newNamed {
    var name:String {get}
}

protocol newAged {
    var age:Int {get}
}

struct NewPerson : newNamed, newAged {
    var name:String
    var age: Int
}


struct newCar:newNamed{
    var name: String
}

func celebrateBirthday(to celebrator:newNamed & newAged) {
    print("Happy birthday \(celebrator.name)!! Now you are \(celebrator.age)")
    
}

let yagom:NewPerson = NewPerson(name: "yagom", age: 22)
celebrateBirthday(to: yagom)

let myCar:newCar = newCar(name: "Bongbong")
//celebrateBirthday(to: myCar)


print(yagom is newNamed)
print(yagom is newAged)

print(myCar is newNamed)
print(myCar is newAged)

if let castedInstance:newNamed = yagom as? newNamed {
    print("\(castedInstance) is NewNamed" )
}

if let castedInstance:newAged = yagom as? newAged {
    print("\(castedInstance) is newAged" )
}

if let castedInstance:newNamed = myCar as? newNamed {
    print("\(castedInstance) is newNamed" )
}

if let castedInstance:newAged = myCar as? newAged {
    print("\(castedInstance) is newAged" )
}


