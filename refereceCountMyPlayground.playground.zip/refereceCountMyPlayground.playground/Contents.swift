//: Playground - noun: a place where people can play

import Foundation

class Person {
    let name:String
    init(name:String) {
        self.name = name
        print("\(name) init")
    }
    
    deinit {
        print("deinit")
    }
}

var ref1:Person?
var ref2:Person?
var ref3:Person?

ref1 = Person(name: "Jeong")
ref2 = ref1
ref3 = ref1

ref3 = nil
ref2 = nil
ref1 = nil

var globalReference:Person?

func foo(){
    let yagom:Person = Person(name: "hoya")
    
    globalReference = yagom
}

foo()