


class ClassA : ClassBDelegateProtocol {
    
    func clickBtn() {
        let insB = ClassB(delegate: self)
        insB.methodB()
    }
    
    func methodA()  {
        print("methondA")
    }
}

class ClassB {
    var delegate:ClassBDelegateProtocol
    
    init(delegate:ClassBDelegateProtocol) {
        self.delegate = delegate
    }
    
    func methodB() {
        print("methodB")
        self.delegate.methodA()
    }
}



protocol ClassBDelegateProtocol {
    func  methodA()
}

