//: Playground - noun: a place where people can play

import Foundation

func swapTwoInts(_ a:inout Int, _ b:inout Int){
    let temporaryA:Int = a
    
    a = b
    b = temporaryA
}

var numberOne:Int = 5
var numberTwo:Int = 10

swapTwoInts(&numberOne, &numberTwo)

print("\(numberOne), \(numberTwo)")



func swapTwoInts<T>(_ a:inout T, _ b:inout T){
    let temporaryA:T = a
    
    a = b
    b = temporaryA
}

swapTwoInts(&numberOne, &numberTwo)

var stringOne:String = "A"
var stringTwo:String = "B"

swapTwoInts(&stringOne, &stringTwo)

print("\(stringOne), \(stringTwo)")



struct IntStack {
    var items = [Int]()
    mutating func push(_ item:Int){
        items.append(item)
    }
    
    mutating func pop() -> Int {
        return items.removeLast()
    }
}

var integerStack:IntStack = IntStack()

integerStack.push(3)
print(integerStack.items)

integerStack.push(2)
print(integerStack.items)



struct Stack<T> {
    var items = [T]()
    
    mutating func push(_ item:T){
        items.append(item)
    }
    
    mutating func pop() -> T {
        return items.removeLast()
    }
}

var doubleStack:Stack<Double> = Stack<Double>()

doubleStack.push(1.0)
print(doubleStack.items)

doubleStack.push(2.0)
print(doubleStack.items)




struct Student {
    var name:String
    var number:Int
}

class School {
    var number:Int = 0
    var students:[Student] = [Student]()
    
    func addStudent(name:String) {
        let student:Student = Student(name: name, number: self.number)
        
        self.students.append(student)
        self.number += 1
    }
    
    func addStudents(names:String...){
        
        for name in names {
            self.addStudent(name: name)
        }
        
    }
    
    subscript(index:Int) -> Student? {
        
        get{
            if index < self.number {
                return self.students[index]
            }
            
            return nil
        }
      
    
    set {
        guard var newStudent:Student = newValue else{
            return
        }
    
        var number:Int = index
    
        if index > self.number{
            number = self.number
            self.number += 1
        }
    
        newStudent.number = number
        self.students[number] = newStudent
    }
    
}
    
    
    subscript(name:String, number:Int) -> Student? {
        return self.students.filter{$0.name == name && $0.number == number}.first
    }
    

}


let highSchool:School = School()

highSchool.addStudents(names: "Mijeong", "Juhyn", "ji", "seong", "moon")

let aStudent:Student? = highSchool[1]

//print("\(aStudent?.name) \(aStudent?.number)")


//print(highSchool["MiJeong"])

highSchool[0] = Student(name: "Hong", number: 9)


