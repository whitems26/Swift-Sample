//: Playground - noun: a place where people can play



class Person {
    let firstName : String
    let lastName : String
    var age: Int
    
    init(firstName:String, lastName:String, age:Int) {
        self.firstName = firstName
        self.lastName = lastName
        self.age = age
    }
    
}

extension Person{
    func getFullName() -> String {
        return self.firstName + " " + self.lastName
    }
}


let person = Person(firstName: "Wayne", lastName: "Roonie", age: 31)


person.getFullName()

extension Person{
    func addAge(num : Int) {
        self.age += num
    }
}

person.addAge(num: 10)
print(person.age)






class MainViewController {
    
    var title:String = "Main"
    
    func openSubView() {
        let subVC = SubViewController()
        subVC.delegate = self
        subVC.title = "Main to Sub"
        subVC.open()
    }
    
    func open() {
        print("\(self.title) Open Main view")
    }
    
    func sendNewMessage(message:String) {
        print("\(message)")
    }
}


class SubViewController {
    
    var title:String = "Sub"
    var delegate:MainViewController?
    
    func open() {
        print("\(self.title) Open Sub view")
        sendMessage()
    }
    
    func sendMessage() {
        delegate?.sendNewMessage(message: "Hello")
    }
}

let mainVC = MainViewController()
mainVC.open()
mainVC.openSubView()




